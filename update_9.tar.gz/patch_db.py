import sqlite3
import os

DB_PATH = 'dealsourcing.db'

def patch_db():
    if not os.path.exists(DB_PATH):
        print("DB not found.")
        return
        
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT id, impact_score, news_grade FROM articles")
    rows = c.fetchall()
    
    updated_count = 0
    for row_id, impact_score, current_grade in rows:
        score = float(impact_score) if impact_score else 0.0
        if score >= 95:
            new_grade = "S"
        elif score >= 90:
            new_grade = "AAA"
        elif score >= 85:
            new_grade = "AA"
        elif score >= 80:
            new_grade = "A"
        elif score >= 70:
            new_grade = "BBB"
        elif score >= 60:
            new_grade = "BB"
        elif score >= 50:
            new_grade = "B"
        else:
            new_grade = "기타"
            
        if current_grade != new_grade:
            c.execute("UPDATE articles SET news_grade = ? WHERE id = ?", (new_grade, row_id))
            updated_count += 1
            
    conn.commit()
    conn.close()
    print(f"Successfully updated {updated_count} rows to the new subdivided grades.")

if __name__ == "__main__":
    patch_db()
